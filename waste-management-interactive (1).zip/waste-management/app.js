'use strict';
const KEY = 'wms_v1';
const AREAS = ['Gandhi Nagar', 'Lake View', 'Market Road', 'Railway Colony', 'Ghansoli', 'Koparkhairane', 'Juinagar', 'Nerul', 'Seawoods', 'Belapur'];
const TYPES = ['General', 'Wet', 'Dry', 'E-Waste'];
const STAT = ['Pending', 'Assigned', 'In Progress', 'Resolved'];
const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const CT = [['wet', 'Wet Waste', '🥬'], ['dry', 'Dry Waste', '📦'], ['ewaste', 'E-Waste', '🔌']];
const ADMIN = { id: 'admin', pass: 'admin123' };
const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fd = e => Object.fromEntries(new FormData(e.target));
const fmt = t => new Date(t).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
const tm = s => { const [h, m] = s.split(':'); return (h % 12 || 12) + ':' + m + (h < 12 ? ' AM' : ' PM'); };
const cls = s => s.toLowerCase().replace(/\s/g, '');
const badge = s => `<span class="badge ${cls(s)}">${s}</span>`;
const cur = () => (location.hash.slice(1) || 'welcome').split('/')[0];
const go = h => { location.hash = h; };
const cnt = (l, k, v) => l.filter(x => x[k] == v).length;

/* ---------- storage ---------- */
function seed() {
  const t = Date.now(), sch = {};
  AREAS.forEach(a => sch[a] = { wet: { days: [1, 2, 3, 4, 5, 6], time: '06:30' }, dry: { days: [2, 5], time: '09:00' }, ewaste: { days: [6], time: '10:00' } });
  return {
    users: [{ id: 1, name: 'Demo Citizen', mobile: '9999999999', email: 'demo@example.com', pass: 'demo123', area: AREAS[0], pin: '400001' }],
    workers: [
      { id: 1, name: 'Ramesh Patil', mobile: '9811111111', area: AREAS[0], duty: 'On Duty' },
      { id: 2, name: 'Sunita Kale', mobile: '9822222222', area: AREAS[1], duty: 'On Duty' },
      { id: 3, name: 'Imran Shaikh', mobile: '9833333333', area: AREAS[2], duty: 'Off Duty' }],
    sch,
    complaints: [
      { id: 'WM1022', uid: 1, type: 'Wet', loc: 'Near Bus Stop, Sector 4', area: AREAS[0], pin: '400001', desc: 'Garbage not collected for two days.', photo: '', status: 'Assigned', at: t - 1728e5, worker: 'Ramesh Patil', note: '' },
      { id: 'WM1023', uid: 1, type: 'E-Waste', loc: 'Park Gate', area: AREAS[0], pin: '400001', desc: 'Old monitors dumped near the gate.', photo: '', status: 'Pending', at: t - 864e5, worker: '', note: '' }],
    pickups: [],
    notifs: [{ id: 1, uid: 1, msg: 'Welcome to Waste Management System.', at: t, read: false }],
    activity: [{ msg: 'System ready', at: t }],
    seq: { c: 1024, p: 456, u: 2, w: 4 }, session: null
  };
}
function load() {
  try { const d = JSON.parse(localStorage.getItem(KEY)); if (d) {
    AREAS.forEach(a => { if (!d.sch[a]) d.sch[a] = { wet: { days: [1, 2, 3, 4, 5, 6], time: '06:30' }, dry: { days: [2, 5], time: '09:00' }, ewaste: { days: [6], time: '10:00' } }; });
    return d;
  } } catch (e) { }
  const d = seed(); localStorage.setItem(KEY, JSON.stringify(d)); return d;
}
let db = load();
function save() { try { localStorage.setItem(KEY, JSON.stringify(db)); } catch (e) { toast('Storage full. Try a smaller photo.'); } }
const me = () => db.users.find(u => u.id === db.session?.id);
const isAdmin = () => db.session?.role === 'admin';
function toast(m) { const t = $('#toast'); t.textContent = m; t.hidden = false; clearTimeout(toast.t); toast.t = setTimeout(() => t.hidden = true, 2600); }
const err = m => { const e = $('#err'); if (e) e.textContent = m; else toast(m); };
const notify = (uid, msg) => db.notifs.unshift({ id: Date.now() + Math.random(), uid, msg, at: Date.now(), read: false });
const log = msg => { db.activity.unshift({ msg, at: Date.now() }); db.activity = db.activity.slice(0, 30); };

/* ---------- helpers ---------- */
const fld = (l, n, v = '', t = 'text', x = '') => `<label>${l}<input name="${n}" type="${t}" value="${esc(v)}" ${x}></label>`;
const sel = (l, n, o, v = '') => `<label>${l}<select name="${n}">${o.map(x => `<option ${x == v ? 'selected' : ''}>${esc(x)}</option>`).join('')}</select></label>`;
const MOB = 'required pattern="[6-9][0-9]{9}" maxlength="10" inputmode="numeric" title="Enter a 10-digit mobile number"';
const PIN = 'required pattern="[0-9]{6}" maxlength="6" inputmode="numeric" title="Enter a 6-digit pincode"';
const when = i => i == 0 ? 'Today' : i == 1 ? 'Tomorrow' : DAYS[(new Date().getDay() + i) % 7];
function nextCol(area) {
  const s = db.sch[area] || db.sch[AREAS[0]], now = new Date().getDay(); let best = null;
  CT.forEach(([k, n]) => { const d = s[k].days; for (let i = 0; i < 7; i++) if (d.includes((now + i) % 7)) { if (!best || i < best.i) best = { i, n, time: s[k].time }; break; } });
  return best;
}
const empty = '<p class="m">Nothing here yet.</p>';
const nCard = n => `<div class="card note ${n.read ? '' : 'new'}"><p>${esc(n.msg)}</p><small>${fmt(n.at)}</small></div>`;
const cCard = c => `<div class="card"><div class="row"><b>${c.id}</b>${badge(c.status)}</div>
<p class="m">${fmt(c.at)} • ${esc(c.type)} waste</p><p>📍 ${esc(c.loc)}, ${esc(c.area)} ${esc(c.pin)}</p>
${c.photo ? `<img class="ph" src="${c.photo}" alt="Waste photo">` : ''}
<div class="steps">${STAT.map((s, i) => `<span class="${i <= STAT.indexOf(c.status) ? 'on' : ''}">${s}</span>`).join('')}</div>
${c.worker ? `<p class="m">Worker: ${esc(c.worker)}</p>` : ''}${c.note ? `<p class="res">Resolution: ${esc(c.note)}</p>` : ''}</div>`;
const pCard = p => `<div class="card"><div class="row"><b>${p.id}</b>${badge(p.status)}</div>
<p class="m">Requested ${fmt(p.at)} • ${esc(p.type)} waste • ${esc(p.qty)}</p><p>📍 ${esc(p.loc)}, ${esc(p.area)}</p><p class="m">Preferred date: ${esc(p.date)}</p>${p.note ? `<p class="m">Note: ${esc(p.note)}</p>` : ''}</div>`;
const okCard = (t, id, st) => shell(t, `<div class="card ok"><div class="big">✅</div><h2>${t}</h2><p>Your ID is</p><p class="id">${id}</p><p>Status: ${badge(st)}</p><a class="btn" href="#reports">View My Reports</a><a class="btn alt" href="#home">Back to Home</a></div>`);

/* ---------- layout ---------- */
const AT = [['admin', 'Dashboard'], ['admin-complaints', 'Complaints'], ['admin-pickups', 'Pickups'], ['admin-workers', 'Workers'], ['admin-schedule', 'Schedule'], ['admin-reports', 'Reports']];
const adminTabs = () => `<nav class="tabs">${AT.map(([h, l]) => `<a href="#${h}" class="${cur() == h || (h == 'admin-complaints' && cur() == 'admin-complaint') ? 'on' : ''}">${l}</a>`).join('')}</nav>`;
function userNav() {
  const r = cur(), un = db.notifs.filter(n => n.uid === db.session.id && !n.read).length;
  const it = [['home', '🏠', 'Home'], ['reports', '📋', 'My Reports'], ['notifs', '🔔', 'Notifications'], ['profile', '👤', 'Profile']];
  return `<nav class="bnav">${it.map(([h, i, l]) => `<a href="#${h}" class="${r == h ? 'on' : ''}"><span>${i}${h == 'notifs' && un ? `<em>${un}</em>` : ''}</span><br>${l}</a>`).join('')}</nav>`;
}
function shell(title, body, back) {
  const adm = isAdmin();
  return `<header class="top">${back ? `<a class="back" href="#${back}" aria-label="Back">←</a>` : ''}<h1>${title}</h1>${adm ? '<button class="lo" onclick="logout()">Logout</button>' : ''}</header>${adm ? adminTabs() : ''}<main>${body}</main>${db.session && !adm ? userNav() : ''}`;
}
function logout() { db.session = null; save(); go('welcome'); }

/* ---------- user views ---------- */
const V = {};
V.welcome = () => `<div class="welcome"><div class="logo">♻️</div><h1>Waste Management System</h1><p class="tag">Cleaner City • Greener Tomorrow</p>
<div class="stack"><a class="btn" href="#login">Login</a><a class="btn alt" href="#register">Register</a></div><a class="link" href="#adminlogin">Local Body Admin Login</a></div>`;
V.login = () => shell('Login', `<form class="card" onsubmit="doLogin(event)">${fld('Mobile number', 'mobile', '', 'tel', MOB)}${fld('Password', 'pass', '', 'password', 'required')}
<p id="err" class="err"></p><button class="btn">Login</button><p class="m">Demo: 9999999999 / demo123</p></form><a class="link" href="#register">New here? Create an account</a>`, 'welcome');
V.register = () => shell('Register', `<form class="card" onsubmit="doReg(event)">${fld('Full name', 'name', '', 'text', 'required minlength="2"')}${fld('Mobile number', 'mobile', '', 'tel', MOB)}${fld('Email', 'email', '', 'email', 'required')}
${sel('Area', 'area', AREAS)}${fld('Pincode', 'pin', '', 'text', PIN)}${fld('Password (min 6 characters)', 'pass', '', 'password', 'required minlength="6"')}<p id="err" class="err"></p><button class="btn">Create Account</button></form>`, 'welcome');
V.adminlogin = () => shell('Admin Login', `<form class="card" onsubmit="doAdmin(event)">${fld('Admin ID', 'id', '', 'text', 'required')}${fld('Password', 'pass', '', 'password', 'required')}<p id="err" class="err"></p><button class="btn">Login</button><p class="m">Demo: admin / admin123</p></form>`, 'welcome');
V.home = () => {
  const u = me(), n = nextCol(u.area), ns = db.notifs.filter(x => x.uid == u.id).slice(0, 3);
  return shell('Waste Management', `<section class="hero"><p>Hello,</p><h2>${esc(u.name)}</h2><small>📍 ${esc(u.area)} • ${esc(u.pin)}</small></section>
<section class="card next"><small>NEXT WASTE COLLECTION</small>${n ? `<h3>${n.n}</h3><p>${when(n.i)} • ${tm(n.time)}</p>` : '<p>No collection scheduled</p>'}</section>
<div class="grid"><a class="tile" href="#report">📸<b>Report Complaint</b></a><a class="tile" href="#pickup">🚛<b>Pickup Request</b></a><a class="tile" href="#schedule">🗓️<b>Collection Schedule</b></a><a class="tile" href="#guide">♻️<b>Recycling Guide</b></a></div>
<h3 class="sec">Recent Updates</h3>${ns.map(nCard).join('') || '<p class="m">No updates yet.</p>'}`);
};
let photoData = '';
V.report = () => {
  photoData = ''; const u = me();
  return shell('Report Waste Complaint', `<form class="card" onsubmit="doReport(event)">${sel('Waste type', 'type', TYPES)}
<label>Waste photo (optional)<input type="file" accept="image/*" onchange="pickPhoto(this)"></label><img id="prev" class="ph" alt="Photo preview" hidden>
${fld('Location / landmark', 'loc', '', 'text', 'required minlength="3"')}${sel('Area', 'area', AREAS, u.area)}${fld('Pincode', 'pin', u.pin, 'text', PIN)}
<label>Description<textarea name="desc" rows="3" required minlength="10" placeholder="Describe the problem"></textarea></label><p id="err" class="err"></p><button class="btn">Submit Complaint</button></form>`, 'home');
};
V.pickup = () => {
  const u = me(), today = new Date().toISOString().slice(0, 10);
  return shell('Waste Pickup Request', `<form class="card" onsubmit="doPickup(event)">${sel('Waste type', 'type', TYPES)}${fld('Quantity (e.g. 3 bags, 20 kg)', 'qty', '', 'text', 'required')}
${fld('Preferred date', 'date', '', 'date', `required min="${today}"`)}${fld('Pickup location / address', 'loc', '', 'text', 'required minlength="3"')}
<label>Additional note (optional)<textarea name="note" rows="2"></textarea></label><p class="m">Area: ${esc(u.area)}</p><p id="err" class="err"></p><button class="btn">Submit Request</button></form>`, 'home');
};
V.schedule = () => {
  const u = me(), s = db.sch[u.area];
  return shell('Collection Schedule', `<div class="card"><small class="m">YOUR AREA</small><h3>📍 ${esc(u.area)} (${esc(u.pin)})</h3></div>${CT.map(([k, n, i]) => `<div class="card"><div class="row"><b>${i} ${n}</b><span>🕒 ${tm(s[k].time)}</span></div><div class="chips">${DAYS.map((d, x) => `<span class="${s[k].days.includes(x) ? 'on' : ''}">${d}</span>`).join('')}</div></div>`).join('')}`, 'home');
};
V.reports = tab => {
  const u = me(), pk = tab == 'pickups', cs = db.complaints.filter(c => c.uid == u.id), ps = db.pickups.filter(p => p.uid == u.id);
  return shell('My Reports', `<div class="seg"><a href="#reports" class="${pk ? '' : 'on'}">Complaints (${cs.length})</a><a href="#reports/pickups" class="${pk ? 'on' : ''}">Pickup Requests (${ps.length})</a></div>${(pk ? ps.map(pCard) : cs.map(cCard)).join('') || empty}`);
};
V.notifs = () => {
  const l = db.notifs.filter(n => n.uid == me().id), c = l.map(nCard).join('');
  l.forEach(n => n.read = true); save();
  return shell('Notifications', c || '<p class="m">No notifications.</p>');
};
V.guide = () => {
  const g = [['🥬', 'Wet Waste', '#2e7d32', 'Kitchen leftovers, vegetable peels, tea leaves, garden waste and flowers. Keep in the green bin; it can be composted.'],
  ['📦', 'Dry Waste', '#1565c0', 'Paper, cardboard, plastic, glass and metal. Rinse and dry before putting in the blue bin so it can be recycled.'],
  ['🔌', 'E-Waste', '#6a1b9a', 'Old phones, chargers, batteries, bulbs and cables. Never put in the dustbin; hand over on the E-Waste collection day.'],
  ['⚠️', 'Hazardous Waste', '#c62828', 'Paint, chemicals, expired medicines, sanitary items and syringes. Seal and label separately and give to the collection staff.']];
  return shell('Recycling Guide', g.map(([i, t, c, d]) => `<div class="card" style="border-left:6px solid ${c}"><h3>${i} ${t}</h3><p>${d}</p></div>`).join(''), 'home');
};
V.profile = () => {
  const u = me(), r = (a, b) => `<div class="kv"><span>${a}</span><b>${esc(b)}</b></div>`;
  return shell('Profile', `<div class="card">${r('Name', u.name)}${r('Mobile', u.mobile)}${r('Email', u.email)}${r('Area', u.area)}${r('Pincode', u.pin)}</div><a class="btn" href="#editprofile">Edit Profile</a><button class="btn danger" onclick="logout()">Logout</button>`);
};
V.editprofile = () => {
  const u = me();
  return shell('Edit Profile', `<form class="card" onsubmit="doEdit(event)">${fld('Full name', 'name', u.name, 'text', 'required minlength="2"')}${fld('Mobile (cannot be changed)', 'mobile', u.mobile, 'tel', 'readonly')}${fld('Email', 'email', u.email, 'email', 'required')}${sel('Area', 'area', AREAS, u.area)}${fld('Pincode', 'pin', u.pin, 'text', PIN)}<p id="err" class="err"></p><button class="btn">Save Changes</button></form>`, 'profile');
};

/* ---------- user actions ---------- */
function doLogin(e) {
  e.preventDefault(); const d = fd(e), u = db.users.find(x => x.mobile == d.mobile && x.pass == d.pass);
  if (!u) return err('Wrong mobile number or password');
  db.session = { id: u.id, role: 'user' }; save(); go('home');
}
function doReg(e) {
  e.preventDefault(); const d = fd(e);
  if (db.users.some(u => u.mobile == d.mobile)) return err('This mobile number is already registered');
  const u = { id: db.seq.u++, name: d.name.trim(), mobile: d.mobile, email: d.email.trim(), pass: d.pass, area: d.area, pin: d.pin };
  db.users.push(u); db.session = { id: u.id, role: 'user' }; notify(u.id, 'Welcome! Your account has been created.'); log(`New citizen registered: ${u.name}`); save(); go('home');
}
function doAdmin(e) {
  e.preventDefault(); const d = fd(e);
  if (d.id != ADMIN.id || d.pass != ADMIN.pass) return err('Wrong admin ID or password');
  db.session = { role: 'admin' }; save(); go('admin');
}
function pickPhoto(inp) {
  const f = inp.files[0]; if (!f) return;
  if (!f.type.startsWith('image/')) { inp.value = ''; return err('Please choose an image file'); }
  const r = new FileReader();
  r.onload = () => {
    const i = new Image();
    i.onload = () => {
      const s = Math.min(1, 600 / i.width), c = document.createElement('canvas');
      c.width = i.width * s; c.height = i.height * s; c.getContext('2d').drawImage(i, 0, 0, c.width, c.height);
      photoData = c.toDataURL('image/jpeg', .7); $('#prev').src = photoData; $('#prev').hidden = false;
    };
    i.src = r.result;
  };
  r.readAsDataURL(f);
}
function doReport(e) {
  e.preventDefault(); const d = fd(e), u = me();
  const c = { id: 'WM' + db.seq.c++, uid: u.id, type: d.type, loc: d.loc.trim(), area: d.area, pin: d.pin, desc: d.desc.trim(), photo: photoData, status: 'Pending', at: Date.now(), worker: '', note: '' };
  db.complaints.unshift(c); notify(u.id, `Complaint ${c.id} submitted. Status: Pending.`); log(`New complaint ${c.id} in ${c.area}`); save(); photoData = '';
  $('#app').innerHTML = okCard('Complaint Submitted', c.id, 'Pending');
}
function doPickup(e) {
  e.preventDefault(); const d = fd(e), u = me();
  const p = { id: 'PR' + db.seq.p++, uid: u.id, type: d.type, qty: d.qty.trim(), date: d.date, note: d.note.trim(), loc: d.loc.trim(), area: u.area, status: 'Pending', at: Date.now() };
  db.pickups.unshift(p); notify(u.id, `Pickup request ${p.id} submitted for ${p.date}.`); log(`New pickup request ${p.id} from ${p.area}`); save();
  $('#app').innerHTML = okCard('Request Submitted', p.id, 'Pending');
}
function doEdit(e) {
  e.preventDefault(); const d = fd(e), u = me();
  Object.assign(u, { name: d.name.trim(), email: d.email.trim(), area: d.area, pin: d.pin }); save(); toast('Profile updated'); go('profile');
}

/* ---------- admin views ---------- */
const st = (l, n) => `<div class="card"><b>${n}</b>${l}</div>`;
const tbl = (h, rows) => `<div class="card" style="overflow-x:auto"><table><tr>${h.map(x => `<th>${x}</th>`).join('')}</tr>${rows.map(r => `<tr>${r.map(x => `<td>${x}</td>`).join('')}</tr>`).join('')}</table></div>`;
V.admin = () => {
  const c = db.complaints, by = {}; AREAS.forEach(a => by[a] = 0); c.forEach(x => by[x.area] = (by[x.area] || 0) + 1);
  const mx = Math.max(1, ...Object.values(by));
  return shell('Local Body Admin', `<div class="stats">${st('Total Complaints', c.length)}${st('Pending Complaints', cnt(c, 'status', 'Pending'))}${st('Resolved Complaints', cnt(c, 'status', 'Resolved'))}${st('Pickup Requests', db.pickups.length)}</div>
<h3 class="sec">Complaints by Area</h3><div class="card">${Object.entries(by).map(([a, n]) => `<div class="bar"><span>${esc(a)}</span><div><i style="width:${n / mx * 100}%"></i></div><b>${n}</b></div>`).join('')}</div>
<h3 class="sec">Recent Activities</h3><div class="card">${db.activity.slice(0, 8).map(a => `<p class="act">${esc(a.msg)}<small>${fmt(a.at)}</small></p>`).join('')}</div>`);
};
V['admin-complaints'] = f => {
  f = f ? decodeURIComponent(f) : 'All';
  const l = db.complaints.filter(c => f == 'All' || c.status == f);
  return shell('Complaint Management', `<div class="filters">${['All', ...STAT].map(s => `<a href="#admin-complaints/${encodeURIComponent(s)}" class="${s == f ? 'on' : ''}">${s}</a>`).join('')}</div>
${l.map(c => { const u = db.users.find(x => x.id == c.uid); return `<div class="card"><div class="row"><b>${c.id}</b>${badge(c.status)}</div><p class="m">${fmt(c.at)} • ${esc(c.type)} • ${esc(c.area)}</p><p>${esc(u?.name || 'Citizen')}: ${esc(c.desc)}</p><a class="btn sm" href="#admin-complaint/${c.id}">View / Manage</a></div>`; }).join('') || empty}`);
};
V['admin-complaint'] = id => {
  const c = db.complaints.find(x => x.id == id); if (!c) return (go('admin-complaints'), '');
  const u = db.users.find(x => x.id == c.uid), i = STAT.indexOf(c.status);
  return shell('Complaint ' + c.id, `${cCard(c)}<div class="card"><small class="m">Reported by</small><p>${esc(u?.name)} • ${esc(u?.mobile)}</p><p>${esc(c.desc)}</p></div>
<form class="card" onsubmit="doManage(event,'${c.id}')"><label>Assign worker<select name="worker"><option value="">Select worker</option>${db.workers.map(w => `<option ${w.name == c.worker ? 'selected' : ''}>${esc(w.name)}</option>`).join('')}</select></label>
${sel('Status', 'status', STAT.slice(i), c.status)}<label>Resolution note<textarea name="note" rows="3">${esc(c.note)}</textarea></label><p id="err" class="err"></p><button class="btn">Save Changes</button></form>`, 'admin-complaints');
};
V['admin-pickups'] = () => shell('Pickup Requests', db.pickups.map(p => {
  const u = db.users.find(x => x.id == p.uid);
  const b = p.status == 'Pending' ? `<button class="btn sm" onclick="setPickup('${p.id}','Accepted')">Accept</button><button class="btn sm danger" onclick="setPickup('${p.id}','Rejected')">Reject</button>` : p.status == 'Accepted' ? `<button class="btn sm" onclick="setPickup('${p.id}','Completed')">Mark Completed</button>` : '';
  return pCard(p).replace(/<\/div>$/, `<p class="m">By ${esc(u?.name)} • ${esc(u?.mobile)}</p><div class="row2">${b}</div></div>`);
}).join('') || empty);
V['admin-workers'] = () => shell('Workers Management', `${db.workers.map(w => `<div class="card"><div class="row"><b>${esc(w.name)}</b><span class="badge ${w.duty == 'On Duty' ? 'resolved' : 'pending'}">${w.duty}</span></div><p class="m">📞 ${esc(w.mobile)} • 📍 ${esc(w.area)}</p><div class="row2"><button class="btn sm alt" onclick="duty(${w.id})">Toggle Duty</button><button class="btn sm danger" onclick="delW(${w.id})">Remove</button></div></div>`).join('')}
<form class="card" onsubmit="addW(event)"><h3>Add Worker</h3>${fld('Name', 'name', '', 'text', 'required minlength="2"')}${fld('Mobile', 'mobile', '', 'tel', MOB)}${sel('Assigned area', 'area', AREAS)}${sel('Duty status', 'duty', ['On Duty', 'Off Duty'])}<button class="btn">Add Worker</button></form>`);
V['admin-schedule'] = a => {
  a = a ? decodeURIComponent(a) : AREAS[0]; const s = db.sch[a];
  return shell('Collection Schedule', `<label>Area<select onchange="go('admin-schedule/'+encodeURIComponent(this.value))">${AREAS.map(x => `<option ${x == a ? 'selected' : ''}>${x}</option>`).join('')}</select></label>
<form onsubmit="doSched(event,'${a}')">${CT.map(([k, n, i]) => `<div class="card days"><b>${i} ${n}</b><p></p>${DAYS.map((d, x) => `<label><input type="checkbox" name="${k}d" value="${x}" ${s[k].days.includes(x) ? 'checked' : ''}>${d}</label>`).join('')}${fld('Collection time', k + 't', s[k].time, 'time', 'required')}</div>`).join('')}<p id="err" class="err"></p><button class="btn">Save Schedule</button></form>`);
};
V['admin-reports'] = () => {
  const c = db.complaints, p = db.pickups;
  return shell('Reports', `<h3 class="sec">Complaints by Status</h3>${tbl(['Status', 'Count'], STAT.map(s => [s, cnt(c, 'status', s)]))}
<h3 class="sec">Complaints by Waste Type</h3>${tbl(['Type', 'Count'], TYPES.map(t => [t, cnt(c, 'type', t)]))}
<h3 class="sec">Area Summary</h3>${tbl(['Area', 'Total', 'Resolved', 'Pickups'], AREAS.map(a => [esc(a), cnt(c, 'area', a), c.filter(x => x.area == a && x.status == 'Resolved').length, cnt(p, 'area', a)]))}
<h3 class="sec">Pickup Requests</h3>${tbl(['Status', 'Count'], ['Pending', 'Accepted', 'Completed', 'Rejected'].map(s => [s, cnt(p, 'status', s)]))}
<button class="btn danger" onclick="resetData()">Reset to Demo Data</button>`);
};

/* ---------- admin actions ---------- */
function doManage(e, id) {
  e.preventDefault(); const d = fd(e), c = db.complaints.find(x => x.id == id);
  if (d.status != 'Pending' && !d.worker) return err('Assign a worker before changing the status');
  if (d.status == 'Resolved' && d.note.trim().length < 5) return err('Add a resolution note to mark as Resolved');
  let s = d.status; if (d.worker && s == 'Pending') s = 'Assigned';
  const changed = s != c.status; Object.assign(c, { worker: d.worker, note: d.note.trim(), status: s });
  if (changed) notify(c.uid, `Complaint ${c.id} status changed to ${s}.`);
  log(`${c.id} updated: ${s}${c.worker ? ' • ' + c.worker : ''}`); save(); toast('Complaint updated'); go('admin-complaints');
}
function setPickup(id, s) {
  const p = db.pickups.find(x => x.id == id); p.status = s;
  notify(p.uid, s == 'Accepted' ? `Pickup request ${id} has been accepted.` : `Pickup request ${id} is now ${s}.`);
  log(`Pickup ${id} ${s.toLowerCase()}`); save(); route();
}
function duty(id) { const w = db.workers.find(x => x.id == id); w.duty = w.duty == 'On Duty' ? 'Off Duty' : 'On Duty'; log(`${w.name} marked ${w.duty}`); save(); route(); }
function delW(id) {
  const w = db.workers.find(x => x.id == id);
  if (!confirm(`Remove ${w.name}?`)) return;
  db.workers = db.workers.filter(x => x.id != id); save(); route();
}
function addW(e) {
  e.preventDefault(); const d = fd(e);
  db.workers.push({ id: db.seq.w++, name: d.name.trim(), mobile: d.mobile, area: d.area, duty: d.duty }); log(`Worker added: ${d.name}`); save(); toast('Worker added'); route();
}
function doSched(e, a) {
  e.preventDefault(); const f = new FormData(e.target);
  for (const [k, n] of CT) if (!f.getAll(k + 'd').length) return err(`Select at least one day for ${n}`);
  CT.forEach(([k]) => db.sch[a][k] = { days: f.getAll(k + 'd').map(Number), time: f.get(k + 't') });
  db.users.filter(u => u.area == a).forEach(u => notify(u.id, `Collection schedule for ${a} has been updated.`));
  log(`Schedule updated for ${a}`); save(); toast('Schedule saved');
}
function resetData() { if (!confirm('Erase all data and restore demo data?')) return; db = seed(); save(); go('welcome'); }

/* ---------- router ---------- */
function route() {
  const [n, a] = (location.hash.slice(1) || 'welcome').split('/'), pub = ['welcome', 'login', 'register', 'adminlogin'];
  const home = () => go(isAdmin() ? 'admin' : 'home');
  if (!db.session) { if (!pub.includes(n)) return go('welcome'); }
  else if (pub.includes(n) || isAdmin() != n.startsWith('admin') || !V[n]) return home();
  if (!V[n]) return go('welcome');
  $('#app').className = isAdmin() ? 'adm' : '';
  $('#app').innerHTML = V[n](a); scrollTo(0, 0);
}
addEventListener('hashchange', route);
route();
